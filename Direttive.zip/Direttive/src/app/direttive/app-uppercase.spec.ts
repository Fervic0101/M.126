import { AppUppercase } from './app-uppercase';

describe('AppUppercase', () => {
  it('should create an instance', () => {
    const directive = new AppUppercase();
    expect(directive).toBeTruthy();
  });
});
