import { Directive } from '@angular/core';

@Directive({
  selector: '[appAppHighlight]'
})
export class AppHighlight {

  constructor() { }

}
